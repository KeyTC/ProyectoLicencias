package Citas;

import java.util.Date;
import java.sql.Time;

public class Cita {

    private int idCitas;
    private Date fecha;
    private Time hora;
    // private Cliente cliente;
    private int idCliente;

    public int getIdCitas() {
        return idCitas;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public int getCliente() {
        return idCliente;
    }

    public void setCliente(int Idcliente) {
        this.idCliente = Idcliente;
    }

    public Cita() {
        this.fecha = new Date();
        this.hora = new Time(6);
        this.idCliente = 1;
    }

    public Cita(int idCita, Date fecha, Time hora, int idcliente) {
        this.idCitas = idCita;
        this.fecha = fecha;
        this.hora = hora;
        this.idCliente = idcliente;
    }

}
