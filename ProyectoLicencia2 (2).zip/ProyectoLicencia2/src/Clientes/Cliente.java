package Clientes;

import Personas.Persona;
import java.util.Date;

public class Cliente {

    private int edad;
    private int idCliente;
    private int idPersona;

    public int getEdad() {
        return edad;
    }

    public Cliente() {
        edad = 1;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }
    

//    public int calcularEdad() {
//        String fecha = String.valueOf(getFechaNacimiento());
//        String año = fecha.substring(0, 4);
//        return 2021 - Integer.parseInt(año);
//    }

    public Cliente(int idCliente, int idPersona) {
        this.idCliente = idCliente;
        this.idPersona = idPersona;
    }

    @Override
    public String toString() {
        return "Cliente{" + "edad=" + edad + '}';
    }
}
