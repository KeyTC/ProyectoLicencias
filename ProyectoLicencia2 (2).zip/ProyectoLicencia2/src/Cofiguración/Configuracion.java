package Cofiguración;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Configuracion {

    private String iP;
    private String nombreB;
    private String Usuario;
    private String contraseña;

    private Connection con;
    public PreparedStatement pst;
    protected ResultSet datos;

    public boolean conectar() {
        try {
            classForName();
            this.con = DriverManager.getConnection("jdbc:mysql://" + this.iP + "/" + this.nombreB, this.Usuario, this.contraseña);
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    public void classForName() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al cargar el driver");
        }
    }

    public void prepararSetencia(String setencia) {
        try {
            pst = this.con.prepareStatement(setencia, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        } catch (SQLException ex) {
            Logger.getLogger(Configuracion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Object[][] seleccionar(Object[] parametros) {
        try {
            this.cargar(parametros);
            this.datos = this.pst.executeQuery();
            return this.toArray(this.datos);
        } catch (SQLException ex) {
            return null;
        }
    }

    public int generarID() {
        try {
            int id = 1;
            datos = pst.executeQuery();
            while (datos.next()) {
                id = datos.getInt(1) + 1;
            }
            return id;
        } catch (SQLException ex) {
            return 0;
        }
    }

    private void cargar(Object[] parametros) throws SQLException {
        int i = 1;
        for (Object parametro : parametros) {
            if (parametro instanceof Integer) {
                this.pst.setInt(i, (int) parametro);
            }
            if (parametro instanceof Double) {
                this.pst.setDouble(i, (double) parametro);
            }
            if (parametro instanceof String) {
                this.pst.setString(i, (String) parametro);
            }
            if (parametro instanceof Date) {
                this.pst.setDate(i, (Date) parametro);
            }
            if (parametro instanceof Time) {
                this.pst.setTime(i, (Time) parametro);
            }
            i++;
        }
    }

    private Object[][] toArray(ResultSet rs) throws SQLException {
        rs.last();
        Object[][] datos = new Object[rs.getRow()][rs.getMetaData().getColumnCount()];
        rs.beforeFirst(); //BOF
        int f = 0;
        while (rs.next()) {
            for (int c = 0; c < rs.getMetaData().getColumnCount(); c++) {
                datos[f][c] = rs.getObject(c + 1);
            }
            f++;
        }
        return datos;
    }

    public boolean ejecutar(Object[] parametros) {
        try {
            this.cargar(parametros);
            return this.pst.executeUpdate() > 0;
        } catch (SQLException ex) {
            return false;
        }
    }

    public Configuracion() {
        this.iP = "127.0.0.1";
        this.nombreB = "ProyectoLicencia";
        this.Usuario = "root";
        this.contraseña = "";
        if (!this.conectar()) {
            throw new NullPointerException();
        }
    }

    public Configuracion(String iP, String nombreB, String Usuario, String contraseña) {
        this.iP = iP;
        this.nombreB = nombreB;
        this.Usuario = Usuario;
        this.contraseña = contraseña;
        if (!this.conectar()) {
            throw new NullPointerException();
        }
    }

}
