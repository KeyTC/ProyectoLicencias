package Controlador;

public interface Controlador<Clase> {
    
    public void guardar(Clase clase);
    public void modificar(Clase clase);
    public void eliminar(Clase clase);

}
