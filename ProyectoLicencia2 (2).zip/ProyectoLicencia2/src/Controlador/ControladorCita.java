package Controlador;

import Citas.Cita;
import Cofiguración.Configuracion;
import DAO.CitaDao;
import Vista.Vista;

public class ControladorCita implements Controlador<Cita> {

    private Cita cita;
    private Vista vista;
    private Configuracion conf;
    private CitaDao citaDao;

    public ControladorCita(Vista vista) {
        this.vista = vista;
        this.cita = new Cita();
        this.vista = vista;
        this.conf = new Configuracion("127.0.0.1", "ProyectoLicencia", "root", "");;
        this.citaDao = new CitaDao(conf);
    }

    public Cita getCita() {
        return cita;
    }

    public void setCita(Cita cita) {
        this.cita = cita;
    }

    public Vista getVista() {
        return vista;
    }

    public void setVista(Vista vista) {
        this.vista = vista;
    }

    public Configuracion getConf() {
        return conf;
    }

    public void setConf(Configuracion conf) {
        this.conf = conf;
    }

    public CitaDao getCitaDao() {
        return citaDao;
    }

    public void setCitaDao(CitaDao citaDao) {
        this.citaDao = citaDao;
    }

    @Override
    public void guardar(Cita clase) {
        if (citaDao.agregar(clase)) {
            this.cita = clase;
            Object[] mensaje = {"ok", "Cliente Agregado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al guardar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Cita clase) {
        if (citaDao.actualizar(clase)) {
            this.cita = clase;
            Object[] mensaje = {"ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al modificado"};
        }
    }

    @Override
    public void eliminar(Cita clase) {
        if (citaDao.eliminar(clase)) {
            this.cita = null;
            Object[] mensaje = {"ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al eliminar"};
        }
    }

}
