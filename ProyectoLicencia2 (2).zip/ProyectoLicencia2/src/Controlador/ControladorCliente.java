package Controlador;

import Clientes.Cliente;
import Cofiguración.Configuracion;
import DAO.ClienteDao;
import Vista.Vista;

public class ControladorCliente implements Controlador<Cliente> {

    private Cliente cliente;
    private Vista vista;
    private Configuracion conf;
    private ClienteDao clienteDao;

    public ControladorCliente(Vista vista) {
        this.cliente = new Cliente();
        this.vista = vista;
        this.conf = new Configuracion("127.0.0.1", "ProyectoLicencia", "root", "");;
        this.clienteDao = new ClienteDao(conf);
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Vista getVista() {
        return vista;
    }

    public void setVista(Vista vista) {
        this.vista = vista;
    }

    public Configuracion getConf() {
        return conf;
    }

    public void setConf(Configuracion conf) {
        this.conf = conf;
    }

    public ClienteDao getClienteDao() {
        return clienteDao;
    }

    public void setClienteDao(ClienteDao clienteDao) {
        this.clienteDao = clienteDao;
    }

    @Override
    public void guardar(Cliente client) {
        if (clienteDao.agregar(client)) {
            this.cliente = client;
            Object[] mensaje = {"ok", "Cliente Agregado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al guardar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Cliente client) {
        if (clienteDao.actualizar(client)) {
            this.cliente = client;
            Object[] mensaje = {"ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al modificado"};
        }
    }

    @Override
    public void eliminar(Cliente client) {
        if (clienteDao.eliminar(client)) {
            this.cliente = null;
            Object[] mensaje = {"ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al eliminar"};
        }
    }


}
