
package Controlador;

import Cofiguración.Configuracion;
import DAO.OficialDao;
import Oficiales.Oficiales;
import Vista.Vista;

public class ControladorOficial implements Controlador<Oficiales>{
    
    private Oficiales ofic;
    private Vista vista;
    private Configuracion conf;
    private OficialDao oficDao;

    public ControladorOficial(Vista vista) {
        this.vista = vista;
        this.ofic= new Oficiales();
        this.vista = vista;
        this.conf = new Configuracion("127.0.0.1", "ProyectoLicencia", "root", "");;
        this.oficDao= new OficialDao(conf);
    }

    public Oficiales getOfic() {
        return ofic;
    }

    public void setOfic(Oficiales ofic) {
        this.ofic = ofic;
    }

    public Vista getVista() {
        return vista;
    }

    public void setVista(Vista vista) {
        this.vista = vista;
    }

    public Configuracion getConf() {
        return conf;
    }

    public void setConf(Configuracion conf) {
        this.conf = conf;
    }

    public OficialDao getOficDao() {
        return oficDao;
    }

    public void setOficDao(OficialDao oficDao) {
        this.oficDao = oficDao;
    }

    @Override
    public void guardar(Oficiales clase) {
    if (oficDao.agregar(clase)) {
            this.ofic = clase;
            Object[] mensaje = {"ok", "Cliente Agregado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al guardar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Oficiales clase) {
      if (oficDao.actualizar(clase)) {
            this.ofic= clase;
            Object[] mensaje = {"ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al modificado"};
        }
    }

    @Override
    public void eliminar(Oficiales clase) {
     if (oficDao.eliminar(clase)) {
            this.ofic= clase;
            Object[] mensaje = {"ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al modificado"};
        }
    }
    
    
    
    
    
}
