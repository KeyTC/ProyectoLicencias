/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Cofiguración.Configuracion;
import DAO.PersonaDao;
import Personas.Persona;
import Vista.Vista;

public class ControladorPersona implements Controlador<Persona> {

    private Persona persona;
    private Vista vista;
    private Configuracion conf;
    private PersonaDao pDao;

    public ControladorPersona(Vista vista) {
        this.persona = new Persona();
        this.vista = vista;
        this.conf = new Configuracion("127.0.0.1", "ProyectoLicencia", "root", "");;
        this.pDao = new PersonaDao(conf);
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public Vista getVista() {
        return vista;
    }

    public void setVista(Vista vista) {
        this.vista = vista;
    }

    public Configuracion getConf() {
        return conf;
    }

    public void setConf(Configuracion conf) {
        this.conf = conf;
    }

    public PersonaDao getpDao() {
        return pDao;
    }

    public void setpDao(PersonaDao pDao) {
        this.pDao = pDao;
    }

    @Override
    public void guardar(Persona pers) {
        if (pDao.agregar(pers)) {
            this.persona = pers;
            Object[] mensaje = {"ok", "Cliente Agregado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al guardar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Persona pers) {
        if (pDao.actualizar(pers)) {
            this.persona = pers;
            Object[] mensaje = {"ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al modificado"};
        }
    }

    @Override
    public void eliminar(Persona pers) {
        if (pDao.eliminar(pers)) {
            this.persona = null;
            Object[] mensaje = {"ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al eliminar"};
        }
    }


}
