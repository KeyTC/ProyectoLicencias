/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Cofiguración.Configuracion;
import DAO.UsuarioDao;
import Usuarios.Usuarios;
import Vista.Vista;

/**
 *
 * @author Usuario
 */
public class ControladorUsuario implements Controlador<Usuarios>{
    
    private Usuarios usuario;
    private Vista vista;
    private Configuracion conf;
    private UsuarioDao USDao;

    public Usuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuarios usuario) {
        this.usuario = usuario;
    }

    public Vista getVista() {
        return vista;
    }

    public void setVista(Vista vista) {
        this.vista = vista;
    }

    public ControladorUsuario(Vista vista) {
        this.usuario = new Usuarios();
        this.vista = vista;
        this.conf = new Configuracion("127.0.0.1", "ProyectoLicencia", "root", "");
        this.USDao = new UsuarioDao(conf);
    }

    @Override
    public void guardar(Usuarios US) {
      if (USDao.agregar(US)) {
          this.usuario = US;
          Object[] mensaje = {"ok", "Usuario " + usuario.getNombreUs() + " Agregado"};
          vista.notificar(mensaje);
      } else {
          Object[] mensaje = {"Error", "Error al guardar"};
          vista.notificar(mensaje);
      }
    
    }

    @Override
    public void modificar(Usuarios US) {
     if (USDao.actualizar(US)) {
            this.usuario= US;
            Object[] mensaje = {"Ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al modificado"};
        }
    
    }

    @Override
    public void eliminar(Usuarios US) {
        if (USDao.eliminar(US)) {
            this.usuario = null;
            Object[] mensaje = {"Ok", "Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error", "Error al eliminar"};
        }
    }


}
