package DAO;

import Citas.Cita;
import Cofiguración.Configuracion;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CitaDao implements Dao<Cita> {

    Configuracion conf;

    public CitaDao(Configuracion conf) {
        this.conf = conf;
    }

    @Override
    public Cita buscar(Cita clas) {
        conf.prepararSetencia("Select * From Citas Where IdCitas = ? ");
        Object[] param = {clas.getIdCitas()};
        Object[][] valores = this.conf.seleccionar(param);
        if (valores != null && valores.length > 0) {
            return new Cita((int) valores[0][0], (java.sql.Date) valores[0][1], (java.sql.Time) valores[0][1], (int) valores[0][1]);
        }
        return null;

    }

    @Override
    public boolean agregar(Cita clas) {
        this.conf.prepararSetencia("Insert into Citas values(?,?,?,?)");
        Object[] param = {clas.getIdCitas(), clas.getFecha(), clas.getHora(), clas.getCliente()};
        return this.conf.ejecutar(param);
    }

    @Override
    public boolean actualizar(Cita clas) {
        this.conf.prepararSetencia("update Citas set Fecha = ?,set  Hora = ?, set IdCliente = ? where IdCitas = ?");
        Object[] param = {clas.getFecha(), clas.getHora(), clas.getCliente(), clas.getIdCitas()};
        return this.conf.ejecutar(param);
    }

    @Override
    public boolean eliminar(Cita clas) {
        this.conf.prepararSetencia("delete Citas where IdCitas = ?");
        Object[] param = {clas.getIdCitas()};
        return this.conf.ejecutar(param);
    }

}
