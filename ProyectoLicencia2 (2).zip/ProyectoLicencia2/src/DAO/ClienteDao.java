package DAO;

import Clientes.Cliente;
import Cofiguración.Configuracion;
import java.sql.SQLException;

public class ClienteDao implements Dao<Cliente> {

    Configuracion conf;

    public ClienteDao(Configuracion conf) {
        this.conf = conf;
    }

    @Override
    public Cliente buscar(Cliente client) {
        conf.prepararSetencia("Select * From Cliente Where IdCliente = ? ");
        Object[] param = {client.getIdCliente()};
        Object[][] valores = this.conf.seleccionar(param);
        if (valores != null && valores.length > 0) {
            return new Cliente((int) valores[0][0], (int) valores[0][1]);
        }
        return null;
    }

    @Override
    public boolean agregar(Cliente client) {
        this.conf.prepararSetencia("Insert into Cliente values(?,?)");
        Object[] param = {client.getIdCliente(), client.getIdPersona()};
        return this.conf.ejecutar(param);

    }

    @Override
    public boolean actualizar(Cliente client) {
        this.conf.prepararSetencia("update Cliente set IdPersona = ? where IdCliente = ?");
        Object[] param = {client.getIdPersona()};
        return this.conf.ejecutar(param);
    }

    @Override
    public boolean eliminar(Cliente client) {
        this.conf.prepararSetencia("delete Cliente where IdCliente = ?");
        Object[] param = {client.getIdCliente()};
        return this.conf.ejecutar(param);
    }

}
