package DAO;

public interface Dao<Clase> {

    public Clase buscar(Clase clas);//read

    public boolean agregar(Clase clas);//create

    public boolean actualizar(Clase clas); //update

    public boolean eliminar(Clase clas); //Delete

}
