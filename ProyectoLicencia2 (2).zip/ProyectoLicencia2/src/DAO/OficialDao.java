package DAO;

import Cofiguración.Configuracion;
import Oficiales.Oficiales;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class OficialDao implements Dao<Oficiales> {

    Configuracion conf;

    public OficialDao(Configuracion conf) {
        this.conf = conf;
    }

    @Override
    public Oficiales buscar(Oficiales clas) {
        conf.prepararSetencia("Select * From Oficiales Where IdOficial = ? ");
        Object[] param = {clas.getIdOficial()};
        Object[][] valores = this.conf.seleccionar(param);
        if (valores != null && valores.length > 0) {
            return new Oficiales((int) valores[0][0], (int) valores[0][1], (double) valores[0][1]);
        }
        return null;

    }

    @Override
    public boolean agregar(Oficiales clas) {
        this.conf.prepararSetencia("Insert into Oficiales values(?,?,?)");
        Object[] param = {clas.getIdOficial(), clas.getIdPersona(), clas.getSalario()};
        return this.conf.ejecutar(param);

    }

    @Override
    public boolean actualizar(Oficiales clas) {
        this.conf.prepararSetencia("update Oficiales set IdPersona = ?, Salario = 2 where IdOficial = ?");
        Object[] param = {clas.getIdPersona(), clas.getSalario(), clas.getIdOficial()};
        return this.conf.ejecutar(param);
    }

    @Override
    public boolean eliminar(Oficiales clas) {
        this.conf.prepararSetencia("delete Oficiales where IdOficial = ?");
        Object[] param = {clas.getIdOficial()};
        return this.conf.ejecutar(param);
    }

}
