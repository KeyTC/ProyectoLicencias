package DAO;

import Cofiguración.Configuracion;
import Personas.Persona;
import java.sql.SQLException;

public class PersonaDao implements Dao<Persona> {

    Configuracion conf;

    public PersonaDao(Configuracion conf) {
        this.conf = conf;
    }

    @Override
    public Persona buscar(Persona pers) {
        conf.prepararSetencia("Select * From Persona Where IdPersona = ? ");
        Object[] param = {pers.getIdPersona()};
        Object[][] valores = this.conf.seleccionar(param);
        if (valores != null && valores.length > 0) {
            return new Persona((int) valores[0][0], (int) valores[0][1],
                    String.valueOf(valores[0][2]), (java.util.Date) valores[0][3], (int) valores[0][4],
                    String.valueOf(valores[0][5]));
        }
        return null;
    }

    @Override
    public boolean agregar(Persona pers) {
        this.conf.prepararSetencia("Insert into Persona values(?,?,?,?,?,?)");
        Object[] param = {pers.getIdPersona(), pers.getNombreComp(),pers.getCedula(),pers.getFechaNacimiento(),pers.getTelefono(),pers.getCorreoElect()};
        return this.conf.ejecutar(param);
    }

    @Override
    public boolean actualizar(Persona pers) {
        this.conf.prepararSetencia("update Persona set NombreCompleto = ?, set Cedula = ?,"
                + "set FechaNacimiento, set Telefono, set CorreoElectronico  where IdPersona = ?");
        Object[] param = {pers.getIdPersona()};
        return this.conf.ejecutar(param);
    }

    @Override
    public boolean eliminar(Persona pers) {
        this.conf.prepararSetencia("delete Persona where IdPersona = ?");
        Object[] param = {pers.getIdPersona()};
        return this.conf.ejecutar(param);
    }

}
