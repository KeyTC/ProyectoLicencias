package DAO;

import Cofiguración.Configuracion;
import Usuarios.Usuarios;

public class UsuarioDao implements Dao<Usuarios> {

    Configuracion conf;

    public UsuarioDao(Configuracion conf) {
        this.conf = conf;
    }

    @Override
    public Usuarios buscar(Usuarios US) {
        conf.prepararSetencia("Select * From Usuarios Where IdUsuario = ? ");
        Object[] param = {US.getIdUsuario()};
        Object[][] valores = this.conf.seleccionar(param);
        if (valores != null && valores.length > 0) {
            return new Usuarios((int) valores[0][0], (int) valores[0][1], String.valueOf(valores[0][2]), String.valueOf(valores[0][3]), (Character) valores[0][4]);
        }
        return null;
    }

    @Override
    public boolean agregar(Usuarios US) {
        this.conf.prepararSetencia("Insert into Usuarios values(?,?,?,?,?)");
        Object[] param = {US.getIdUsuario(), US.getIdPersona(), US.getNombreUs(), US.getContraseña(), String.valueOf(US.getTipoUS())};
        return this.conf.ejecutar(param);
    }

    @Override
    public boolean actualizar(Usuarios US) {
        this.conf.prepararSetencia("update Usuarios set IdPersona = ?,set NombreUS = ?,set TipoUsuario where IdUsuario=?");
        Object[] param = {US.getIdPersona(), US.getNombreUs(), US.getTipoUS()};
        return this.conf.ejecutar(param);
    }

    @Override
    public boolean eliminar(Usuarios US) {
        this.conf.prepararSetencia("delete Usuarios where IdUsuario=?");
        Object[] param = {US.getIdUsuario()};
        return this.conf.ejecutar(param);
    }

}
