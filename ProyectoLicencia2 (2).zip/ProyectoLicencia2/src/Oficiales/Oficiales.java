package Oficiales;

public class Oficiales {

    private int idOficial;
    private int idPersona;
    private double salario;

    public int getIdOficial() {
        return idOficial;
    }

    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        if (salario > 0) {
            this.salario = salario;
        }
    }

    public double calcularDedupcion(String dedupcion) {
        switch (dedupcion) {
            case "enfermedad","maternidad" -> {
                return (getSalario() * 5.5) / 100;
            }

            case "invalidez", "muerte" -> {
                return (getSalario() * 3.84) / 100;
            }

            case "aporte del trabajador" -> {
                return (getSalario() * 1) / 100;
            }

            case "aporte a la asociación solidarista" -> {
                return (getSalario() * 3.3) / 100;
            }

            case "Impuesto sobre la renta" -> {

            }
        }
        return 0;
    }

    public Oficiales() {
        this.idOficial = 1;
        this.idPersona = 1;
        this.salario = 1000;
    }

    public Oficiales(int idOficial, int idPersona, double salario) {
        this.idOficial = idOficial;
        this.idPersona = idPersona;
        this.salario = salario;
    }

    @Override
    public String toString() {
        return "Oficiales{" + "salario=" + salario + '}';
    }

}
