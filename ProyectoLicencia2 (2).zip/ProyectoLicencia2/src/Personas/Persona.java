package Personas;

import java.util.Date;

public class Persona {

    private int idPersona;
    protected int cedula;
    protected String nombreComp;
    protected Date fechaNacimiento;
    protected int telefono;
    protected String correoElect;

    public int getIdPersona() {
        return idPersona;
    }
  
    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getNombreComp() {
        return nombreComp;
    }

    public void setNombreComp(String nombreComp) {
        this.nombreComp = nombreComp;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getCorreoElect() {
        return correoElect;
    }

    public void setCorreoElect(String correoElect) {
        this.correoElect = correoElect;
    }

    public Persona() {
        this.cedula = 0;
        this.nombreComp = "";
        this.fechaNacimiento = new Date();
        this.telefono = 0;
        this.correoElect = "";
    }

    public Persona(int cedula, String nombreComp, Date fechaNacimiento) {
        this.cedula = cedula;
        this.nombreComp = nombreComp;
        this.fechaNacimiento = fechaNacimiento;
    }

    public Persona(int id,int cedula, String nombreComp, Date fechaNacimiento, int telefono, String correoElect) {
        this.idPersona = id;
        this.cedula = cedula;
        this.nombreComp = nombreComp;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correoElect = correoElect;
    }

    @Override
    public String toString() {
        return "Persona{" + "cedula=" + cedula + ", nombreComp=" + nombreComp + ", fechaNacimiento=" + fechaNacimiento + ", telefono=" + telefono + ", correoElect=" + correoElect + '}';
    }

}
