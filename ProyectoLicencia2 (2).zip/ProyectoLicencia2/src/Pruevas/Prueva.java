package Pruevas;

import Oficiales.Oficiales;
import java.util.Date;
import java.util.Timer;

public class Prueva {

    private Date fecha;
    private Timer hora;
    private Oficiales oficial;
    private String observaciones;
    private int nota;
    private char estado;

    public final char APROBADO = 'A';
    public final char REPROBADO = 'R';

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Timer getHora() {
        return hora;
    }

    public void setHora(Timer hora) {
        this.hora = hora;
    }

    public Oficiales getOficial() {
        return oficial;
    }

    public void setOficial(Oficiales oficial) {
        this.oficial = oficial;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    public char getEstado() {
        return estado;
    }

    public void asignarEstado() {
        if (this.nota >= 80) {
            this.estado = APROBADO;
        }
    }

    public Prueva() {
        this.fecha = new Date();
        this.hora = new Timer();
        this.oficial = new Oficiales();
        this.observaciones = "";
        this.nota = 0;
        this.estado = REPROBADO;
    }

    public Prueva(Date fecha, Timer hora, Oficiales oficial, String observaciones, int nota) {
        this.fecha = fecha;
        this.hora = hora;
        this.oficial = oficial;
        this.observaciones = observaciones;
        this.nota = nota;
        this.estado = 'R';
    }

}
