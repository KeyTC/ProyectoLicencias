package Usuarios;

public class Usuarios {

    private String nombreUs;
    private String contraseña;
    private char tipoUS;
    private int idUsuario;
    private int idPersona;

    public char getTipoUS() {
        return tipoUS;
    }

    public void setTipoUS(char tipoUS) {
        this.tipoUS = tipoUS;
    }

    public String getContraseña() {
        return contraseña;
    }

    public int getIdPersona() {
        return idPersona;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public String getNombreUs() {
        return nombreUs;
    }

    public void setNombreUs(String nombreUs) {
        this.nombreUs = nombreUs;
    }

    public Usuarios() {
        this.nombreUs = "";
        this.contraseña = "";
        this.tipoUS = 'S';
    }

    public Usuarios(int idUsuario, int idPersona, String nombreUs, String contraseña, char tipo) {
        this.idUsuario = idUsuario;
        this.nombreUs = nombreUs;
        this.contraseña = contraseña;
        this.tipoUS = tipo;
        this.idPersona = idPersona;
    }

    public Usuarios(int idPersona, String nombreUs, String contraseña, char tipo) {
        this.idUsuario = idUsuario;
        this.nombreUs = nombreUs;
        this.contraseña = contraseña;
        this.tipoUS = tipo;
        this.idPersona = idPersona;
    }

    @Override
    public String toString() {
        return "Usuarios{" + "nombreUs=" + nombreUs + ", contrase\u00f1a=" + contraseña + ", tipo=" + tipoUS + '}';
    }
}
