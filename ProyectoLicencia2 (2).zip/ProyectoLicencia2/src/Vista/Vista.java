package Vista;

public interface Vista {

    public void notificar(Object[] valores);

}
